#ifdef CS333_P5
#include "types.h"
#include "user.h"
int
main(void)
{
  printf(1, "Not imlpemented yet.\n");
  exit();
}

#endif
